
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="text-center p-3 text-sm text-gray-500 border-t border-gray-100">
      By <span className="text-blue-600 font-semibold">Mas Dimz</span>
    </footer>
  );
};

export default Footer;
