
import React from 'react';
import PlayerInput from './PlayerInput';

interface InputPageProps {
  players: string[];
  error: string | null;
  onPlayerNameChange: (index: number, name: string) => void;
  onStartPrediction: () => void;
}

const InputPage: React.FC<InputPageProps> = ({ players, error, onPlayerNameChange, onStartPrediction }) => {
  return (
    <div className="p-5">
      <h2 className="text-center text-xl font-semibold mb-4 text-gray-700">🧠 Daftar Player</h2>
      {players.map((player, index) => (
        <PlayerInput
          key={index}
          index={index}
          value={player}
          onChange={onPlayerNameChange}
        />
      ))}
      {error && <p className="text-red-500 text-sm text-center mb-3">{error}</p>}
      <button
        onClick={onStartPrediction}
        className="w-full border-none rounded-lg p-3 text-white font-semibold text-base cursor-pointer bg-gradient-to-r from-blue-600 to-purple-500 transition-opacity hover:opacity-90 active:scale-95"
      >
        Mulai Prediksi
      </button>
    </div>
  );
};

export default InputPage;
