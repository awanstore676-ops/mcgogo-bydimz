
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-500 text-white text-center p-4 font-bold text-lg">
      ⚡ PREDIKSI MUSUH MC GOGO ⚡
    </header>
  );
};

export default Header;
