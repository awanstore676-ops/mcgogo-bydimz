
import React from 'react';

interface PlayerInputProps {
  index: number;
  value: string;
  onChange: (index: number, value: string) => void;
}

const PlayerInput: React.FC<PlayerInputProps> = ({ index, value, onChange }) => {
  return (
    <div className="flex items-center mb-3 bg-gray-100 rounded-lg p-2 transition-all focus-within:ring-2 focus-within:ring-blue-500">
      <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-500 rounded-md text-white font-semibold flex justify-center items-center text-sm flex-shrink-0">
        {index + 1}
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(index, e.target.value)}
        placeholder={`Player ${index + 1}`}
        className="border-none bg-transparent ml-3 flex-1 outline-none text-base text-gray-800 placeholder-gray-400"
      />
    </div>
  );
};

export default PlayerInput;
