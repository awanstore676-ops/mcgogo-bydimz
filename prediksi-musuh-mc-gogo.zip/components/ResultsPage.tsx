
import React from 'react';

interface ResultsPageProps {
  players: string[];
  onGoBack: () => void;
  onReset: () => void;
}

const FormationResult: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div>
    <h3 className="font-bold text-gray-900 mb-2">🌀 {title}</h3>
    <div className="space-y-1">{children}</div>
  </div>
);

const ResultsPage: React.FC<ResultsPageProps> = ({ players, onGoBack, onReset }) => {
  const P = players;

  return (
    <div className="p-5">
      <h2 className="text-center text-xl font-semibold mb-4 text-gray-700">📜 Hasil Prediksi</h2>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-gray-800 space-y-4">
        <FormationResult title="Formasi A">
          <p>II-6 → {P[0]}</p>
          <p>III-1 → {P[1]}</p>
          <p>III-2 → {P[2]}</p>
          <p>III-3 → <span className="font-bold">babak creep</span></p>
          <p>III-4 → {P[3]}</p>
          <p>III-5 → {P[4]}</p>
          <p>III-6 → {P[5]}</p>
          <p>VI-1 → {P[6]}</p>
        </FormationResult>
        <FormationResult title="Formasi B">
          <p>II-6 → {P[0]}</p>
          <p>III-1 → {P[1]}</p>
          <p>III-2 → {P[2]}</p>
          <p>III-3 → <span className="font-bold">babak creep</span></p>
          <p>III-4 → {P[3]}</p>
          <p>III-5 → {P[4]}</p>
          <p>III-6 → {P[6]}</p>
          <p>VI-1 → {P[5]}</p>
        </FormationResult>
      </div>
      <div className="mt-4 flex gap-4">
        <button
          onClick={onGoBack}
          className="flex-1 border-none rounded-lg p-3 text-white font-semibold text-base cursor-pointer bg-gradient-to-r from-gray-500 to-gray-600 transition-opacity hover:opacity-90 active:scale-95"
        >
          ⬅ Kembali
        </button>
        <button
          onClick={onReset}
          className="flex-1 border-none rounded-lg p-3 text-white font-semibold text-base cursor-pointer bg-gradient-to-r from-blue-600 to-purple-500 transition-opacity hover:opacity-90 active:scale-95"
        >
          🔄 Reset
        </button>
      </div>
    </div>
  );
};

export default ResultsPage;
