
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import InputPage from './components/InputPage';
import ResultsPage from './components/ResultsPage';

enum Page {
  Input,
  Results,
}

const App: React.FC = () => {
  const [players, setPlayers] = useState<string[]>(Array(7).fill(''));
  const [currentPage, setCurrentPage] = useState<Page>(Page.Input);
  const [error, setError] = useState<string | null>(null);

  const handlePlayerNameChange = useCallback((index: number, name: string) => {
    setPlayers(prevPlayers => {
      const newPlayers = [...prevPlayers];
      newPlayers[index] = name;
      return newPlayers;
    });
  }, []);

  const handleStartPrediction = useCallback(() => {
    if (players.some(p => p.trim() === '')) {
      setError('Lengkapi semua nama player!');
      return;
    }
    setError(null);
    setCurrentPage(Page.Results);
  }, [players]);

  const handleGoBack = useCallback(() => {
    setCurrentPage(Page.Input);
  }, []);

  const handleReset = useCallback(() => {
    setPlayers(Array(7).fill(''));
    setError(null);
    setCurrentPage(Page.Input);
  }, []);

  return (
    <div className="bg-gray-100 min-h-screen flex justify-center items-start p-5">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200">
        <Header />
        <main>
          {currentPage === Page.Input && (
            <InputPage
              players={players}
              error={error}
              onPlayerNameChange={handlePlayerNameChange}
              onStartPrediction={handleStartPrediction}
            />
          )}
          {currentPage === Page.Results && (
            <ResultsPage
              players={players}
              onGoBack={handleGoBack}
              onReset={handleReset}
            />
          )}
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default App;
